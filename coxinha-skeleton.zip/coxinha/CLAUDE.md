# Coxinha — Context pro Claude Code

Docs detalhados:
- [README.md](./README.md) — setup, overview
- [ARCHITECTURE.md](./ARCHITECTURE.md) — módulos, fluxos, IPC
- [DECISIONS.md](./DECISIONS.md) — ADRs
- [ROADMAP.md](./ROADMAP.md) — fases

## Regras essenciais

1. **Filesystem é canonical.** `~/coxinha/*.md/.wav/.webp`. SQLite é só índice.
2. **Windows-first.** Testa Windows antes de mac/Linux.
3. **Zero network na F1.** Sem sync, sem OAuth. Tudo local.
4. **Tray-resident.** Abrir janela = show/focus, nunca re-spawn.
5. **Rust puro.** Sem Python sidecar. `whisper-rs`/`transcribe-rs` + `pyannote-rs`/`speakrs`.
6. **Traits pluggable.** `Transcriber` e `Diarizer` são traits, engines via config.
7. **`genai` pra LLM.** Provider via config, não hardcoded.
8. **BlockNote pra editor.** Não reinventa.
9. **Modelos ONNX lazy load.** Não carrega no boot.

## Estilo Rust

- Erros em comandos Tauri: `anyhow::Result`
- Lib interna: `thiserror` pra tipos custom quando fizer sentido
- Logs: `tracing` + `tracing-subscriber`
- Async: `tokio` (vem com Tauri)
- Tests: `#[cfg(test)]` inline

## Estilo frontend

- Componentes functional, TypeScript strict
- Zustand pra state global (evita Redux/Context boilerplate)
- shadcn components copy-paste, não dependência
- Tailwind, sem CSS modules

## O que NÃO fazer

- Não adicionar banco como source of truth (filesystem é)
- Não fazer chamadas externas sem user configurar explícito
- Não criar schema proprietário de nota (sempre markdown)
- Não ligar auto-update sem flag
- Não enviar analytics/telemetria
- Não criar macros Rust novas (usa as que já existem)

## Vibe coding patterns

Ref: Akita FrankMD. Build-build-build-STOP-refactor.

Quando um arquivo passar de ~400 linhas ou um módulo de ~800 linhas,
para e refatora antes de adicionar features.
