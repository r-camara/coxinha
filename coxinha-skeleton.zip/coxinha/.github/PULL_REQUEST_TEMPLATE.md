## O que

<!-- O que essa PR faz? 1-2 frases. -->

## Por que

<!-- Contexto: qual problema resolve ou qual feature adiciona. -->

## Como testar

<!-- Passos pra quem revisa validar. -->

## Checklist

- [ ] `cargo fmt --all`
- [ ] `cargo clippy --workspace --all-targets`
- [ ] `cargo test --workspace`
- [ ] `pnpm typecheck`
- [ ] Se mudou config/schema: atualizei `DECISIONS.md`?
- [ ] Se quebrei API IPC: rodei `pnpm tauri dev` pra regenerar `bindings.ts`?
