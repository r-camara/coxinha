# Roadmap

## F1 — MVP Local-first (em andamento)

**Meta:** substituir Fathom pro uso pessoal no Windows.

### Core
- [x] Setup Tauri + React + BlockNote + shadcn
- [ ] Tray-resident + auto-launch + global shortcuts
- [ ] Editor de notas com paste de imagem (compressão WebP auto)
- [ ] Daily notes automáticas
- [ ] Storage em filesystem (`~/coxinha/notes/*.md`)
- [ ] SQLite FTS5 pra busca

### Áudio e reuniões
- [ ] Call detector (Teams/Zoom/Meet)
- [ ] Gravação mic + loopback WASAPI
- [ ] Trait Transcriber com WhisperTranscriber default
- [ ] ParakeetTranscriber opcional via feature
- [ ] Trait Diarizer com NoneDiarizer default
- [ ] PyannoteDiarizer opcional

### LLM
- [ ] Resumo via genai (Claude + Ollama)
- [ ] Prompt templates configuráveis
- [ ] Integração de reunião com nota markdown

### Atalhos globais
- [ ] `Ctrl+Alt+N` — nova nota rápida
- [ ] `Ctrl+Alt+C` — abre última view
- [ ] `Ctrl+Alt+A` — agenda do dia
- [ ] `Ctrl+Alt+M` — lista de meetings
- [ ] `Ctrl+Alt+R` — toggle gravação manual

## F1.5 — Ricos blocks (pós-MVP)

- [ ] Bloco Mermaid (~60 linhas custom BlockNote)
- [ ] Bloco Excalidraw (modal fullscreen estilo VS Code ext)
- [ ] Wiki-links `[[nota]]` com autocomplete
- [ ] Tags `#projeto` com filtro
- [ ] Upgrade diarização: `SpeakrsDiarizer`

## F2 — Multi-PC via sync opcional

- [ ] Backend Rust (Axum + Postgres)
- [ ] Cliente sync no desktop (push/pull via WebSocket)
- [ ] Conflict resolution (Yjs-compat com BlockNote)
- [ ] Web UI read-mostly (consultar de outro PC)
- [ ] Auth: Keycloak self-hosted ou JWT simples

## F3 — Integrações externas

- [ ] OAuth Microsoft (Graph API) — loopback + PKCE
- [ ] OAuth Google (Calendar + Tasks)
- [ ] Sync MS Todo / Google Tasks → agenda unificada
- [ ] Sync GitHub PRs/issues/assigned
- [ ] Sync Azure DevOps work items
- [ ] Timeline de "tudo que preciso fazer hoje"

## F4 — Camada de IA avançada

- [ ] Embeddings automáticos (fastembed local)
- [ ] Qdrant ou lancedb embutido
- [ ] Chat com o vault ("o que falei com Fulano em Março?")
- [ ] Servidor MCP exposto pra Claude Desktop, Cursor, etc
- [ ] Memórias de longo prazo (facts extraídos)
- [ ] Briefing automático pré-reunião
- [ ] Auto-tag + auto-linking de notas novas

## F5 — Além

- [ ] Coaching pós-reunião (análise de padrões)
- [ ] Screen capture de slides com OCR
- [ ] Gravação de vídeo bot-less (desktop capture)
- [ ] Knowledge graph visual (React Flow)
- [ ] PWA mobile companion
- [ ] Cross-platform: macOS via CoreML, Linux via Vulkan
