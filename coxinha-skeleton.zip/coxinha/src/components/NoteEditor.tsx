import { useEffect, useMemo, useState } from 'react';
import { useCreateBlockNote } from '@blocknote/react';
import { BlockNoteView } from '@blocknote/shadcn';
import '@blocknote/core/fonts/inter.css';
import '@blocknote/shadcn/style.css';
import { invoke } from '@tauri-apps/api/core';
import { useAppStore } from '../lib/store';

interface Props {
  noteId: string;
}

export function NoteEditor({ noteId }: Props) {
  const [initialMarkdown, setInitialMarkdown] = useState<string | null>(null);
  const saveNote = useAppStore((s) => s.saveNote);

  useEffect(() => {
    (async () => {
      const res = await invoke<{ markdown: string }>('get_note', { id: noteId });
      setInitialMarkdown(res.markdown);
    })();
  }, [noteId]);

  if (initialMarkdown === null) {
    return <LoadingSkeleton />;
  }

  return (
    <EditorInner
      noteId={noteId}
      initialMarkdown={initialMarkdown}
      onSave={(md) => saveNote(noteId, md)}
    />
  );
}

function EditorInner({
  noteId,
  initialMarkdown,
  onSave,
}: {
  noteId: string;
  initialMarkdown: string;
  onSave: (md: string) => void;
}) {
  const editor = useCreateBlockNote({
    // Paste de imagem: intercepta, comprime pra WebP, salva como attachment
    uploadFile: async (file: File) => {
      const compressed = await compressImage(file);
      const arrayBuffer = await compressed.arrayBuffer();
      const bytes = Array.from(new Uint8Array(arrayBuffer));

      const relPath = await invoke<string>('save_attachment', {
        filename: compressed.name,
        bytes,
      });

      // Retorna URL que BlockNote coloca no src da imagem.
      // Tauri serve arquivos do vault via asset protocol.
      return `coxinha://attachments/${relPath.replace(/^attachments\//, '')}`;
    },
  });

  // Carrega markdown inicial no editor
  useEffect(() => {
    (async () => {
      const blocks = await editor.tryParseMarkdownToBlocks(initialMarkdown);
      editor.replaceBlocks(editor.document, blocks);
    })();
  }, [editor, initialMarkdown]);

  // Debounced save ao mudar
  const debouncedSave = useMemo(() => {
    let timer: ReturnType<typeof setTimeout> | null = null;
    return () => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(async () => {
        const md = await editor.blocksToMarkdownLossy(editor.document);
        onSave(md);
      }, 500);
    };
  }, [editor, onSave]);

  return (
    <div className="h-full overflow-auto bn-container">
      <BlockNoteView
        editor={editor}
        onChange={debouncedSave}
        data-note-id={noteId}
      />
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="p-8 space-y-3 animate-pulse">
      <div className="h-8 w-1/2 bg-[hsl(var(--muted))] rounded" />
      <div className="h-4 w-full bg-[hsl(var(--muted))] rounded" />
      <div className="h-4 w-5/6 bg-[hsl(var(--muted))] rounded" />
      <div className="h-4 w-4/6 bg-[hsl(var(--muted))] rounded" />
    </div>
  );
}

/**
 * Comprime imagem pra WebP antes de upload.
 *
 * - Redimensiona se largura > 1600px
 * - Converte pra WebP quality 0.85
 * - Fallback: retorna arquivo original se falhar
 *
 * Complementa o que o backend faz (ele também comprime defensivamente,
 * mas fazer aqui reduz payload IPC).
 */
async function compressImage(file: File): Promise<File> {
  if (!file.type.startsWith('image/')) return file;

  try {
    const bitmap = await createImageBitmap(file);
    const MAX_WIDTH = 1600;

    const scale = bitmap.width > MAX_WIDTH ? MAX_WIDTH / bitmap.width : 1;
    const outW = Math.round(bitmap.width * scale);
    const outH = Math.round(bitmap.height * scale);

    const canvas = new OffscreenCanvas(outW, outH);
    const ctx = canvas.getContext('2d')!;
    ctx.drawImage(bitmap, 0, 0, outW, outH);

    const blob = await canvas.convertToBlob({
      type: 'image/webp',
      quality: 0.85,
    });

    const newName = file.name.replace(/\.[^.]+$/, '.webp');
    return new File([blob], newName, { type: 'image/webp' });
  } catch (e) {
    console.warn('Image compression failed, using original', e);
    return file;
  }
}
