import { useAppStore } from '../lib/store';
import { Calendar, FileText, Mic, Settings } from 'lucide-react';
import clsx from 'clsx';

type View = 'notes' | 'agenda' | 'meetings' | 'settings';

interface Props {
  current: View;
  onNavigate: (v: View) => void;
}

export function Sidebar({ current, onNavigate }: Props) {
  const notes = useAppStore((s) => s.notes);
  const activeNoteId = useAppStore((s) => s.activeNoteId);
  const setActiveNote = useAppStore((s) => s.setActiveNote);
  const newNote = useAppStore((s) => s.newNote);

  return (
    <aside className="w-72 border-r border-[hsl(var(--border))] flex flex-col bg-[hsl(var(--muted))]">
      <header className="p-4 flex items-center justify-between">
        <h1 className="font-bold text-lg">Coxinha</h1>
        <button
          onClick={() => newNote()}
          className="text-xs px-2 py-1 rounded bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]"
          title="Nova nota (Ctrl+Alt+N)"
        >
          + Nova
        </button>
      </header>

      <nav className="px-2 space-y-1">
        <NavItem
          icon={<FileText size={16} />}
          label="Notas"
          active={current === 'notes'}
          onClick={() => onNavigate('notes')}
        />
        <NavItem
          icon={<Calendar size={16} />}
          label="Agenda"
          active={current === 'agenda'}
          onClick={() => onNavigate('agenda')}
        />
        <NavItem
          icon={<Mic size={16} />}
          label="Reuniões"
          active={current === 'meetings'}
          onClick={() => onNavigate('meetings')}
        />
      </nav>

      {current === 'notes' && (
        <div className="flex-1 overflow-auto px-2 mt-4">
          <h2 className="text-xs uppercase text-[hsl(var(--muted-foreground))] px-2 mb-1">
            Recentes
          </h2>
          <ul className="space-y-0.5">
            {notes.map((n) => (
              <li key={n.id}>
                <button
                  onClick={() => setActiveNote(n.id)}
                  className={clsx(
                    'w-full text-left px-2 py-1.5 rounded text-sm truncate',
                    activeNoteId === n.id
                      ? 'bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]'
                      : 'hover:bg-[hsl(var(--accent))]/50'
                  )}
                >
                  {n.title || '(sem título)'}
                </button>
              </li>
            ))}
          </ul>
          {notes.length === 0 && (
            <p className="px-2 text-sm text-[hsl(var(--muted-foreground))]">
              Nenhuma nota ainda.
            </p>
          )}
        </div>
      )}

      <footer className="p-2 border-t border-[hsl(var(--border))]">
        <NavItem
          icon={<Settings size={16} />}
          label="Configurações"
          active={current === 'settings'}
          onClick={() => onNavigate('settings')}
        />
      </footer>
    </aside>
  );
}

function NavItem({
  icon,
  label,
  active,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={clsx(
        'w-full flex items-center gap-2 px-2 py-1.5 rounded text-sm',
        active
          ? 'bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] font-medium'
          : 'hover:bg-[hsl(var(--accent))]/50'
      )}
    >
      {icon}
      {label}
    </button>
  );
}
