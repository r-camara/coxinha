import { create } from 'zustand';
import { invoke } from '@tauri-apps/api/core';

export interface Note {
  id: string;
  title: string;
  path: string;
  tags: string[];
  created_at: string;
  updated_at: string;
}

interface AppStore {
  notes: Note[];
  activeNoteId: string | null;

  loadNotes: () => Promise<void>;
  setActiveNote: (id: string | null) => void;
  newNote: () => Promise<void>;
  saveNote: (id: string, markdown: string) => Promise<void>;
  deleteNote: (id: string) => Promise<void>;
  searchNotes: (query: string) => Promise<Note[]>;
}

export const useAppStore = create<AppStore>((set, get) => ({
  notes: [],
  activeNoteId: null,

  async loadNotes() {
    const notes = await invoke<Note[]>('list_notes');
    set({ notes });
  },

  setActiveNote(id) {
    set({ activeNoteId: id });
  },

  async newNote() {
    const note = await invoke<Note>('create_note', {
      title: 'Nova nota',
      content: '# Nova nota\n\n',
    });
    await get().loadNotes();
    set({ activeNoteId: note.id });
  },

  async saveNote(id, markdown) {
    await invoke('update_note', { id, content: markdown });
    // Recarrega lista pra pegar novo título/updated_at
    await get().loadNotes();
  },

  async deleteNote(id) {
    await invoke('delete_note', { id });
    const { activeNoteId, notes } = get();
    set({
      activeNoteId: activeNoteId === id ? null : activeNoteId,
      notes: notes.filter((n) => n.id !== id),
    });
  },

  async searchNotes(query) {
    return await invoke<Note[]>('search_notes', { query });
  },
}));
