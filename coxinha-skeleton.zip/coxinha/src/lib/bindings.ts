/**
 * Arquivo gerado automaticamente pelo `tauri-specta` em dev.
 *
 * Não edite manualmente — será sobrescrito no próximo `pnpm tauri dev`.
 *
 * Quando o app rodar pela primeira vez em dev, ele substitui este stub
 * por tipos reais dos commands Rust.
 */

// Stub temporário. Substituído automaticamente na primeira execução.
export type Note = {
  id: string;
  title: string;
  path: string;
  tags: string[];
  created_at: string;
  updated_at: string;
};

export type Meeting = {
  id: string;
  title: string;
  started_at: string;
  ended_at: string | null;
  duration_seconds: number | null;
  participants: string[];
  recording_path: string | null;
  has_transcript: boolean;
  has_summary: boolean;
  source_app: string | null;
};

export type TranscriptSegment = {
  start: number;
  end: number;
  text: string;
  speaker: string | null;
  confidence: number | null;
};

export type Transcript = {
  meeting_id: string;
  language: string | null;
  segments: TranscriptSegment[];
};
