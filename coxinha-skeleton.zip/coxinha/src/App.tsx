import { useEffect, useState } from 'react';
import { listen } from '@tauri-apps/api/event';
import { NoteEditor } from './components/NoteEditor';
import { Sidebar } from './components/Sidebar';
import { useAppStore } from './lib/store';

type View = 'notes' | 'agenda' | 'meetings' | 'settings';

export default function App() {
  const [view, setView] = useState<View>('notes');
  const loadNotes = useAppStore((s) => s.loadNotes);
  const activeNoteId = useAppStore((s) => s.activeNoteId);
  const newNote = useAppStore((s) => s.newNote);

  useEffect(() => {
    loadNotes();

    // Navegação por evento do backend (global shortcut)
    const unlistenNav = listen<string>('navigate', async (e) => {
      const route = e.payload;
      if (route === '/notes/new') {
        await newNote();
        setView('notes');
      } else if (route === '/agenda') {
        setView('agenda');
      } else if (route === '/meetings') {
        setView('meetings');
      } else if (route === '/settings') {
        setView('settings');
      } else if (route === '/actions/toggle-recording') {
        // TODO
      }
    });

    // Toast de call detectada
    const unlistenCall = listen<{ app_name: string; process_name: string }>(
      'call-detected',
      (e) => {
        console.log('Call detected', e.payload);
        // TODO: mostrar toast com botão "gravar"
      }
    );

    return () => {
      unlistenNav.then((f) => f());
      unlistenCall.then((f) => f());
    };
  }, [loadNotes, newNote]);

  return (
    <div className="h-screen w-screen flex bg-[hsl(var(--background))]">
      <Sidebar current={view} onNavigate={setView} />

      <main className="flex-1 overflow-hidden">
        {view === 'notes' && activeNoteId && <NoteEditor noteId={activeNoteId} />}
        {view === 'notes' && !activeNoteId && <EmptyState />}
        {view === 'agenda' && <AgendaView />}
        {view === 'meetings' && <MeetingsView />}
        {view === 'settings' && <SettingsView />}
      </main>
    </div>
  );
}

function EmptyState() {
  const newNote = useAppStore((s) => s.newNote);
  return (
    <div className="h-full flex flex-col items-center justify-center gap-4 text-[hsl(var(--muted-foreground))]">
      <p>Nenhuma nota selecionada.</p>
      <button
        onClick={() => newNote()}
        className="px-4 py-2 rounded-md bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] hover:opacity-90"
      >
        Nova nota (Ctrl+Alt+N)
      </button>
    </div>
  );
}

function AgendaView() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Agenda</h1>
      <p className="text-[hsl(var(--muted-foreground))]">
        Em breve: daily notes, tarefas, lembretes.
      </p>
    </div>
  );
}

function MeetingsView() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Reuniões</h1>
      <p className="text-[hsl(var(--muted-foreground))]">
        Em breve: histórico, player, transcript, resumos.
      </p>
    </div>
  );
}

function SettingsView() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Configurações</h1>
      <p className="text-[hsl(var(--muted-foreground))]">
        Em breve: engines (Whisper/Parakeet), diarização, LLM provider, atalhos.
      </p>
    </div>
  );
}
