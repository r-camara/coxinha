# Coxinha

> Massa por fora, saboroso por dentro. Teu segundo cérebro local com IA.

Notetaker desktop **bot-less** com gravação de reuniões, transcrição e
memória pessoal. Roda 100% local, funciona offline, tray-resident com
startup instantâneo.

## Features (F1 — MVP)

- ⚡ Tray-resident, atalho `Ctrl+Alt+N` abre em <50ms
- 📝 Editor Notion-like (BlockNote + shadcn) com paste de imagem
- 💾 Notas em Markdown no disco (`~/coxinha/`)
- 🎙️ Detecta Teams/Meet/Zoom ativos e oferece gravar
- 🎧 Gravação mic + áudio do sistema (loopback WASAPI)
- 🧠 Transcrição local: Parakeet (ONNX) ou Whisper (CUDA)
- 🗣️ Diarização local: pyannote-rs ou speakrs
- 📄 Resumo via Claude, Ollama local, ou outras APIs

## Quick start

### Pré-requisitos

- Windows 11 (primário) ou macOS/Linux (experimental)
- Rust stable (1.82+)
- Node.js 20+
- pnpm (`npm i -g pnpm`)
- **Dev:** WSL2 Ubuntu (recomendado, build Rust 2-3x mais rápido)
- (Opcional) CUDA Toolkit 12+ para GPU
- (Opcional) Ollama rodando local para resumo offline

### Desenvolvimento

```bash
# Clone + deps
git clone <repo>
cd coxinha
pnpm install

# Baixa modelos (script pega Parakeet INT8 + pyannote segmentation)
./scripts/download-models.sh

# Roda em dev (hot reload)
pnpm tauri dev
```

Primeira compilação do Rust demora 3-5 minutos (compila whisper.cpp +
baixa ONNX Runtime). Builds incrementais ~10s.

### Build release

```bash
# CPU only
pnpm tauri build

# Com aceleração GPU
pnpm tauri build --features cuda
```

Gera `src-tauri/target/release/bundle/` com `.msi` e `.exe`.

### Rodando via WSL2 + Windows

Projeto compila dentro do WSL2 (Linux), mas o binário Tauri pra Windows
tem que ser buildado no Windows (WebView2, WASAPI). Fluxo:

- **Dev:** `pnpm tauri dev` dentro do WSL pra iteração rápida
  (roda como GUI Linux via WSLg)
- **Build Windows:** via GitHub Actions (`release.yml`) ou rodando
  `pnpm tauri build` direto do PowerShell

## Estrutura

- [ARCHITECTURE.md](./ARCHITECTURE.md) — módulos, fluxos, IPC
- [DECISIONS.md](./DECISIONS.md) — ADRs (por que cada escolha)
- [ROADMAP.md](./ROADMAP.md) — fases F1–F5
- [CLAUDE.md](./CLAUDE.md) — context mínimo pro Claude Code

## License

MIT — ver [LICENSE](./LICENSE).
