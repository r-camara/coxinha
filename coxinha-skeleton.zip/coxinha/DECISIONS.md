# Architecture Decision Records

Formato ADR enxuto. Uma decisão = um bloco.

---

## ADR-001: Tauri, não Electron ou web puro

**Data:** 2026-04-18
**Status:** Accepted

### Contexto
Precisamos de gravação de áudio do sistema (loopback) e captura de
eventos de chamada — ambos requerem acesso nativo ao SO. Web puro
não resolve.

### Decisão
Tauri 2 com frontend React.

### Consequências
- **+** Binário pequeno (~30MB), startup rápido, WebView2 já vem em Windows 11
- **+** Rust backend casa com whisper-rs, wasapi, windows crate
- **−** WebView2 tem menos consistência que Chrome entre versões
- **−** Tauri mobile é experimental — se virar produto cross-device, rever

---

## ADR-002: Local-first na F1, sync na F2

**Data:** 2026-04-18
**Status:** Accepted

### Contexto
MVP tem que funcionar sem dependência de backend/internet. Granola
e Fathom validaram que notetaker local-first é viável.

### Decisão
F1 = tudo local, filesystem canonical. F2 adiciona sync server Rust
(Axum + Postgres) opcional. Arquitetura preparada.

### Consequências
- **+** Zero setup inicial, usável offline
- **+** Dados sempre do usuário
- **−** Multi-PC requer Fase 2
- **−** Risco de bitrot se user perder PC
  (mitigável com Syncthing apontado pra `~/coxinha/`)

---

## ADR-003: BlockNote como editor

**Data:** 2026-04-18
**Status:** Accepted

### Contexto
Precisamos de editor Notion-like com paste de imagem, mínimo
esforço. Alternativas: Tiptap puro, Lexical, CodeMirror, custom.

### Decisão
BlockNote com `@blocknote/shadcn`.

### Consequências
- **+** Setup de ~5 linhas
- **+** Slash menu, drag handles, paste imagem, dark mode grátis
- **+** Markdown in/out automático (Obsidian-compat)
- **+** Meetily usa (validação)
- **−** Menos flexível que Tiptap puro pra custom blocks muito específicos
  (mitigação: extensions Tiptap ainda funcionam via `_tiptapOptions`)

---

## ADR-004: Rust puro, sem Python sidecar

**Data:** 2026-04-18
**Status:** Accepted

### Contexto
AiNotes usa Python sidecar pra faster-whisper. Funciona, mas
adiciona +200MB no bundle e complexidade de build.

### Decisão
100% Rust. `whisper-rs` (binding whisper.cpp) + `transcribe-rs`
(Parakeet/ONNX) + `pyannote-rs` ou `speakrs` (diarização).

### Consequências
- **+** Binário único, sem runtime Python
- **+** Startup sem overhead de subprocess
- **−** whisper-rs build no Windows pode requerer toolchain completo;
  CI resolve

---

## ADR-005: `genai` crate pra LLM

**Data:** 2026-04-18
**Status:** Accepted

### Contexto
Troca livre entre Ollama local, Claude API, OpenAI, Groq, OpenRouter.
Cada provider tem SDK próprio.

### Decisão
Crate `genai` (jeremychone/rust-genai) como abstração única.
Config do provider em `~/coxinha/.coxinha/config.toml`.

### Consequências
- **+** Trocar provider é mudar string no config
- **+** Streaming, tool use, structured output uniformes
- **−** Versão 0.x, API muda. Pinar versão, revisar em upgrades

---

## ADR-006: Cargo workspace pra monorepo

**Data:** 2026-04-18
**Status:** Accepted

### Contexto
Teremos no futuro `src-tauri/` (app) + `backend/` (sync server F2)
+ `shared/` (tipos comuns).

### Decisão
Cargo workspace no root. Começa com `src-tauri/` e `shared/`.
Adiciona `backend/` em F2 sem refactor.

### Consequências
- **+** Um `target/`, um `Cargo.lock`, builds incrementais cross-crate
- **+** Tipos `Meeting`, `Note` em `shared/` evitam duplicação
- **−** Frontend fica fora do workspace (pnpm gerencia)

---

## ADR-007: Tray-resident pattern

**Data:** 2026-04-18
**Status:** Accepted

### Contexto
Startup cold do WebView2 é ~200-400ms. Inaceitável pro fluxo
"atalho → digitar imediatamente".

### Decisão
App inicia junto com Windows (auto-launch plugin). Janela é criada
hidden no boot. Fechar janela = hide, não close. Global shortcuts
abrem janela já aquecida.

### Consequências
- **+** Tempo percebido <50ms
- **+** Call detector roda sempre em background
- **−** App consome ~80MB RAM em idle (aceitável em PCs com GPU)
- **−** Quit de verdade só via menu do tray

---

## ADR-008: STT como trait com múltiplas impls (Whisper + Parakeet)

**Data:** 2026-04-18
**Status:** Accepted

### Contexto
Whisper é padrão de fato, mas Parakeet-TDT-0.6B-v3 da NVIDIA é
mais rápido (6.34% WER vs Whisper-large-v3 em benchmarks HF Open ASR)
e suporta 25 línguas incluindo português. Diferentes usuários podem
preferir diferentes trade-offs.

### Decisão
Módulo `transcriber/` com trait `Transcriber: Send + Sync`.
Implementações:
- `WhisperTranscriber` via `whisper-rs` (default, fácil de buildar)
- `ParakeetTranscriber` via `transcribe-rs` + `ort`

Escolha via `config.toml`. Modelos ficam em `~/coxinha/.coxinha/models/`.

### Consequências
- **+** User escolhe engine sem recompilar
- **+** Parakeet-TDT-v3 beat Whisper-large em throughput e WER multilíngue
- **+** `transcribe-rs` adiciona Canary, Moonshine, SenseVoice grátis
- **−** Dois pipelines pra manter
- **−** Parakeet em PT é treinado em europeu (não BR), pode ter pequena
  degradação — compensa por velocidade

---

## ADR-009: Diarization como trait com múltiplas impls

**Data:** 2026-04-18
**Status:** Accepted

### Contexto
Reunião com múltiplos speakers precisa de diarização. Opções em Rust:
- `pyannote-rs` — pipeline simples, CPU
- `speakrs` — pipeline pyannote community-1 completo, 2-7x mais rápido
  em CUDA, matching pyannote DER
- `sherpa-onnx` — C++ com bindings, pesado mas completo

### Decisão
Trait `Diarizer: Send + Sync`. Implementações:
- `NoneDiarizer` (default dev, passa segments sem speaker labels)
- `PyannoteDiarizer` via `pyannote-rs` (simples, estável)
- `SpeakrsDiarizer` via `speakrs` (produção)

### Consequências
- **+** MVP não depende de diarização funcionando
- **+** Upgrade de pyannote-rs → speakrs é só trocar config
- **−** Modelos ONNX adicionais a baixar (~100MB)

---

## ADR-010: ONNX Runtime (`ort`) como runtime de ML

**Data:** 2026-04-18
**Status:** Accepted

### Contexto
Parakeet, pyannote segmentation, wespeaker embeddings, speakrs —
todos usam ONNX. Precisamos de runtime unificado.

### Decisão
`ort` (pykeio) como dependência shared. Execution providers:
- CPU (default)
- CUDA (feature `cuda`)
- DirectML (Windows, feature `directml`)
- CoreML (Mac, futuro)

### Consequências
- **+** Um único runtime de ML, baixado uma vez
- **+** Suporte a TensorRT se quiser acelerar ainda mais
- **−** `ort 2.0.0-rc` ainda é RC, pode ter breaking changes
- **−** DLLs ONNX precisam ser empacotadas (copy-dylibs feature)

---

## ADR-011: Mermaid e Excalidraw como F1.5

**Data:** 2026-04-18
**Status:** Accepted

### Contexto
Queremos blocos de diagrama no editor, mas complexidade de custom
blocks no BlockNote + tamanho dos pacotes (mermaid ~500KB,
excalidraw ~1MB+).

### Decisão
Não incluir na F1. F1.5 depois que MVP estiver funcionando.

### Consequências
- **+** F1 entrega mais rápido
- **+** Reduz surface area pra bugs iniciais
- **−** Sem diagramas no primeiro mês
