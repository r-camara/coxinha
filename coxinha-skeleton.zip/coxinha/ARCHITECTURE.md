# Arquitetura

## Visão geral

Coxinha é um app desktop Tauri tray-resident. Toda lógica pesada
(áudio, STT, diarização, LLM, DB) roda em Rust no processo nativo.
O frontend React é visual apenas — não toma decisões.

```
┌──────────────────────────────────────────────────────────┐
│  Frontend (React + BlockNote + shadcn + Tailwind)        │
│  ├─ NoteEditor    ← BlockNote WYSIWYG, paste imagem       │
│  ├─ MeetingsList  ← histórico com player                  │
│  ├─ Agenda        ← daily notes + tarefas                 │
│  └─ Tray UI       ← toast de detecção de call             │
│                                                           │
├──── IPC tipado (tauri-specta) ──────────────────────────┤
│                                                           │
│  Backend Rust (src-tauri/)                                │
│  ├─ lib.rs           → setup, tray, shortcuts             │
│  ├─ db.rs            → rusqlite + FTS5                    │
│  ├─ storage.rs       → filesystem vault                   │
│  ├─ recorder.rs      → cpal + wasapi (mic + loopback)     │
│  ├─ call_detector.rs → windows crate (COM)                │
│  ├─ transcriber/     → trait + impls (Whisper/Parakeet)   │
│  ├─ diarizer/        → trait + impls (pyannote/speakrs)   │
│  └─ summarizer.rs    → genai (Claude/Ollama/OpenAI)       │
│                                                           │
├── SO (Windows / macOS / Linux) ─────────────────────────┤
│  ├─ Tray icon + global shortcuts                          │
│  ├─ WASAPI (áudio loopback + mic)                         │
│  ├─ COM (audio session polling pro call detector)         │
│  └─ Filesystem (~/coxinha/)                               │
└──────────────────────────────────────────────────────────┘
```

## Filesystem layout

**Vault do usuário é canonical. DB é só índice reconstrutível.**

```
~/coxinha/
├── notes/
│   ├── 2026-04-18-ideia-produto.md
│   └── 2026-04-19-reuniao-cliente.md
├── meetings/
│   └── 2026-04-18-standup/
│       ├── metadata.json       # participantes, horário
│       ├── recording.wav       # 16kHz mono
│       ├── transcript.json     # segments + speakers
│       └── summary.md          # LLM gerou
├── attachments/
│   └── 2026-04-18-143025.webp  # imagens coladas (auto-WebP)
├── daily/
│   └── 2026-04-18.md           # daily note
└── .coxinha/
    ├── index.db                # SQLite + FTS5
    ├── config.toml             # preferências
    └── models/                 # ONNX + GGUF cacheados
        ├── parakeet-tdt-0.6b-v3-int8/
        ├── segmentation-3.0.onnx
        └── wespeaker-voxceleb-resnet34-LM.onnx
```

Qualquer arquivo do vault é editável em qualquer editor Markdown
(Obsidian, VS Code, Notepad). Coxinha não cria formato proprietário.

## Módulos Rust

### `lib.rs`
Entrada. Configura:
- Tray icon + menu (Open, Record, Settings, Quit)
- Global shortcuts (`Ctrl+Alt+N/C/A/M/R`)
- Hidden window no boot
- Auto-launch plugin
- Spawn de tasks: `call_detector`, `db_watcher`

### `db.rs`
`rusqlite` com FTS5. Tabelas:
- `notes` (id, path, title, tags, updated_at)
- `meetings` (id, title, started_at, duration, participants_json)
- `notes_fts` (virtual table FTS5)

Reconstrutível a partir do vault.

### `storage.rs`
Abstração do vault:
- `save_note(id, content)` → grava `.md`
- `load_note(id)` → lê `.md`
- `save_attachment(bytes, hint)` → WebP em `attachments/`
- `watch()` → notifica mudanças externas (Obsidian, VS Code)

### `recorder.rs`
`cpal` + `wasapi`. Mistura mic + loopback em WAV 16kHz mono
(ideal pra Parakeet/Whisper). Grava em chunks pra resiliência.

### `call_detector.rs`
Polling de 3s em `IAudioSessionManager2` (via crate `windows`).
Detecta processos conhecidos (Teams, Zoom, Meet em browser).
Emite evento `call-detected`.

### `transcriber/`
**Trait pluggable.** Implementações:

| Impl | Crate | Modelo | Notas |
|------|-------|--------|-------|
| `WhisperTranscriber` | `whisper-rs` | whisper.cpp GGUF | Default dev. CPU rápido, CUDA opcional |
| `ParakeetTranscriber` | `transcribe-rs` | Parakeet TDT v3 ONNX INT8 | 25 línguas incl. PT, mais rápido que Whisper |

Escolha via `config.toml`:
```toml
[transcriber]
engine = "parakeet"  # ou "whisper"
model_path = "~/coxinha/.coxinha/models/parakeet-tdt-0.6b-v3-int8"
accelerator = "cuda"  # ou "cpu", "directml"
```

### `diarizer/`
**Trait pluggable.** Implementações:

| Impl | Crate | Pipeline | Notas |
|------|-------|----------|-------|
| `PyannoteDiarizer` | `pyannote-rs` | segmentation-3.0 + wespeaker | Simples, CPU ok |
| `SpeakrsDiarizer` | `speakrs` | Pyannote community-1 completo | 2-7x mais rápido, CUDA |
| `NoneDiarizer` | — | passa segments sem speaker | Default dev |

### `summarizer.rs`
Crate `genai`. Provider via config:
```toml
[summarizer]
provider = "claude"  # ollama, claude, openai, groq, openrouter
model = "claude-sonnet-4-5"
```

Templates de prompt em `src-tauri/resources/prompts/`.

## IPC

Frontend chama backend via `invoke()`. Types gerados com `tauri-specta`:

```ts
import { commands } from '@/lib/tauri';

const note = await commands.createNote({
  title: 'Ideia nova',
  content: '# Header\n\nbody',
});
```

Comandos principais:
- `create_note`, `update_note`, `delete_note`, `list_notes`, `search_notes`
- `start_recording`, `stop_recording`, `list_recordings`
- `transcribe_meeting`, `diarize_meeting`, `summarize_meeting`
- `get_active_calls`, `subscribe_call_events`
- `get_config`, `update_config`

## Startup flow

```
T=0ms    → Tauri spawna processo
T=20ms   → lib.rs executa, cria tray icon
T=40ms   → Hidden window criada (Webview não renderiza ainda)
T=50ms   → Global shortcuts registrados
T=60ms   → Call detector task spawnada em background
T=70ms   → DB aberto (lazy load)
T=80ms   → Ready. App consumindo ~80MB RAM

User aperta Ctrl+Alt+N:
T=0ms    → Shortcut dispara
T=10ms   → Window.show() + focus
T=30ms   → Editor BlockNote focado, cursor pronto
         ↑ user já está digitando
```

**Modelos de STT/diarização carregam lazy** (só no primeiro uso).
Primeira transcrição demora ~5s no cold-load, subsequentes <1s.

## Sync futuro (F2)

Arquitetura preparada. Módulo `sync.rs` (futuro) fará:
- Push de mudanças via WebSocket pro backend
- Pull incremental em startup
- Conflict resolution via CRDT (Yjs-compat pro BlockNote)

Filesystem continua canonical. Backend vira réplica autoritária
quando disponível.
