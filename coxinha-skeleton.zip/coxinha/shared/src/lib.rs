//! Tipos compartilhados entre desktop app (src-tauri) e futuro backend (F2).

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use specta::Type;
use uuid::Uuid;

// -- Notas --

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct Note {
    pub id: Uuid,
    pub title: String,
    pub path: String,
    pub tags: Vec<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct NoteContent {
    pub note: Note,
    pub markdown: String,
}

// -- Reuniões --

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct Meeting {
    pub id: Uuid,
    pub title: String,
    pub started_at: DateTime<Utc>,
    pub ended_at: Option<DateTime<Utc>>,
    pub duration_seconds: Option<u32>,
    pub participants: Vec<String>,
    pub recording_path: Option<String>,
    pub has_transcript: bool,
    pub has_summary: bool,
    pub source_app: Option<String>, // Teams, Zoom, Meet, etc
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct TranscriptSegment {
    pub start: f32,
    pub end: f32,
    pub text: String,
    pub speaker: Option<String>,
    pub confidence: Option<f32>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct Transcript {
    pub meeting_id: Uuid,
    pub language: Option<String>,
    pub segments: Vec<TranscriptSegment>,
}

// -- Call detection --

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct ActiveCall {
    pub app_name: String,
    pub process_name: String,
    pub pid: u32,
    pub is_browser: bool,
    pub detected_at: DateTime<Utc>,
}

// -- LLM providers --

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum LlmProvider {
    Ollama { endpoint: String, model: String },
    Claude { model: String },
    OpenAI { model: String },
    Groq { model: String },
    OpenRouter { model: String },
}

// -- Transcriber config --

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
#[serde(tag = "engine", rename_all = "snake_case")]
pub enum TranscriberConfig {
    Whisper {
        model_path: String,
        accelerator: Accelerator,
    },
    Parakeet {
        model_dir: String,
        accelerator: Accelerator,
    },
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, Type)]
#[serde(rename_all = "lowercase")]
pub enum Accelerator {
    Cpu,
    Cuda,
    DirectMl,
    CoreMl,
}

// -- Diarizer config --

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
#[serde(tag = "engine", rename_all = "snake_case")]
pub enum DiarizerConfig {
    None,
    Pyannote {
        segmentation_model: String,
        embedding_model: String,
    },
    Speakrs {
        model_dir: String,
        accelerator: Accelerator,
    },
}

// -- App config (full) --

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct AppConfig {
    pub vault_path: String,
    pub transcriber: TranscriberConfig,
    pub diarizer: DiarizerConfig,
    pub llm: LlmProvider,
    pub autostart: bool,
    pub shortcuts: ShortcutsConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct ShortcutsConfig {
    pub new_note: String,
    pub open_app: String,
    pub agenda: String,
    pub meetings: String,
    pub toggle_recording: String,
}

impl Default for ShortcutsConfig {
    fn default() -> Self {
        Self {
            new_note: "Ctrl+Alt+N".into(),
            open_app: "Ctrl+Alt+C".into(),
            agenda: "Ctrl+Alt+A".into(),
            meetings: "Ctrl+Alt+M".into(),
            toggle_recording: "Ctrl+Alt+R".into(),
        }
    }
}
