# Icons

Coloque aqui os ícones do app:

- `32x32.png` (tray + Windows)
- `128x128.png` (Linux + fallback)
- `128x128@2x.png` (Retina)
- `icon.ico` (Windows installer)
- `icon.icns` (macOS)
- `icon.png` (tray Linux)

Gerar a partir de um `coxinha.png` 1024x1024:

```bash
pnpm tauri icon path/to/coxinha.png
```

O comando gera todos os tamanhos automaticamente em `src-tauri/icons/`.
