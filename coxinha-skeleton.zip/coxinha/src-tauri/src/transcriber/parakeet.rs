//! Parakeet TDT via `transcribe-rs` + ONNX Runtime.
//!
//! Modelo recomendado: `nvidia/parakeet-tdt-0.6b-v3` em INT8.
//! Suporta 25 línguas europeias incluindo português (variante europeia).
//!
//! Download via `scripts/download-models.sh`.

#![cfg(feature = "stt-parakeet")]

use std::path::{Path, PathBuf};
use std::sync::Mutex;

use anyhow::{Context, Result};
use async_trait::async_trait;
use shared::*;
use uuid::Uuid;

use super::Transcriber;

pub struct ParakeetTranscriber {
    model_dir: PathBuf,
    accelerator: Accelerator,
    model: Mutex<Option<transcribe_rs::onnx::parakeet::ParakeetModel>>,
}

impl ParakeetTranscriber {
    pub fn new(model_dir: PathBuf, accelerator: Accelerator) -> Result<Self> {
        // Seta accelerator global do ort (transcribe-rs expõe helper)
        use transcribe_rs::{set_ort_accelerator, OrtAccelerator};
        let ort_acc = match accelerator {
            Accelerator::Cpu => OrtAccelerator::Cpu,
            Accelerator::Cuda => OrtAccelerator::Cuda,
            Accelerator::DirectMl => OrtAccelerator::DirectMl,
            Accelerator::CoreMl => OrtAccelerator::CoreMl,
        };
        set_ort_accelerator(ort_acc);

        Ok(Self {
            model_dir,
            accelerator,
            model: Mutex::new(None),
        })
    }

    fn ensure_loaded(&self) -> Result<()> {
        let mut guard = self.model.lock().unwrap();
        if guard.is_some() {
            return Ok(());
        }
        let model = transcribe_rs::onnx::parakeet::ParakeetModel::load(
            &self.model_dir,
            &transcribe_rs::onnx::Quantization::Int8,
        )
        .with_context(|| format!("loading parakeet from {}", self.model_dir.display()))?;
        *guard = Some(model);
        Ok(())
    }
}

#[async_trait]
impl Transcriber for ParakeetTranscriber {
    async fn transcribe_file(&self, wav: &Path) -> Result<Transcript> {
        self.ensure_loaded()?;

        let wav = wav.to_path_buf();
        let model_dir = self.model_dir.clone();
        let _ = self.accelerator; // usado no ensure_loaded via global ort setting

        let (segments, language) = tokio::task::spawn_blocking(move || -> Result<(Vec<TranscriptSegment>, Option<String>)> {
            use transcribe_rs::onnx::parakeet::{ParakeetModel, ParakeetParams, TimestampGranularity};
            use transcribe_rs::onnx::Quantization;

            let mut model = ParakeetModel::load(&model_dir, &Quantization::Int8)?;
            let samples = transcribe_rs::audio::read_wav_samples(&wav)?;
            let result = model.transcribe_with(
                &samples,
                &ParakeetParams {
                    timestamp_granularity: Some(TimestampGranularity::Segment),
                    ..Default::default()
                },
            )?;

            // `result.text` é string única + segments com timestamps
            let segs: Vec<TranscriptSegment> = result
                .segments
                .into_iter()
                .map(|s| TranscriptSegment {
                    start: s.start as f32,
                    end: s.end as f32,
                    text: s.text.trim().to_string(),
                    speaker: None,
                    confidence: None,
                })
                .collect();

            Ok((segs, result.language))
        })
        .await??;

        Ok(Transcript {
            meeting_id: Uuid::nil(),
            language,
            segments,
        })
    }
}
