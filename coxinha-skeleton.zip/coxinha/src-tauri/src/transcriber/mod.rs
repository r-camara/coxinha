//! Trait `Transcriber` com múltiplas implementações plugáveis.
//!
//! Escolha via `config.toml`:
//! ```toml
//! [transcriber]
//! engine = "parakeet"  # ou "whisper"
//! model_dir = "~/coxinha/.coxinha/models/parakeet-tdt-0.6b-v3-int8"
//! accelerator = "cuda"
//! ```

use std::path::Path;
use std::sync::Arc;

use anyhow::Result;
use async_trait::async_trait;
use shared::*;
use uuid::Uuid;

pub mod parakeet;
pub mod whisper;

/// Interface comum. Todas as impls são `Send + Sync` pra ser guardado em `Arc`.
#[async_trait]
pub trait Transcriber: Send + Sync {
    /// Transcreve um arquivo WAV (16kHz mono esperado).
    async fn transcribe_file(&self, wav: &Path) -> Result<Transcript>;

    /// Conveniência: transcreve o recording de uma meeting e grava transcript.json.
    async fn transcribe_meeting(&self, id: Uuid) -> Result<Transcript> {
        let _ = id;
        anyhow::bail!("transcribe_meeting default impl not wired")
    }
}

pub fn build(config: &TranscriberConfig) -> Result<Arc<dyn Transcriber>> {
    match config {
        TranscriberConfig::Whisper {
            model_path,
            accelerator,
        } => {
            #[cfg(feature = "stt-whisper")]
            {
                Ok(Arc::new(whisper::WhisperTranscriber::new(
                    model_path.into(),
                    *accelerator,
                )?))
            }
            #[cfg(not(feature = "stt-whisper"))]
            {
                let _ = (model_path, accelerator);
                anyhow::bail!("stt-whisper feature not enabled at compile time")
            }
        }
        TranscriberConfig::Parakeet {
            model_dir,
            accelerator,
        } => {
            #[cfg(feature = "stt-parakeet")]
            {
                Ok(Arc::new(parakeet::ParakeetTranscriber::new(
                    model_dir.into(),
                    *accelerator,
                )?))
            }
            #[cfg(not(feature = "stt-parakeet"))]
            {
                let _ = (model_dir, accelerator);
                anyhow::bail!("stt-parakeet feature not enabled at compile time")
            }
        }
    }
}
