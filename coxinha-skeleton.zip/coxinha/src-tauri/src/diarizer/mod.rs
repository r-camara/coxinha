//! Trait `Diarizer` com múltiplas implementações plugáveis.
//!
//! Aplica speaker labels a segments já transcritos, ou gera segments
//! do zero e faz merge com o transcript.

use std::path::Path;
use std::sync::Arc;

use anyhow::Result;
use async_trait::async_trait;
use shared::*;

pub mod none;
#[cfg(feature = "diarize-pyannote")]
pub mod pyannote;
// #[cfg(feature = "diarize-speakrs")]
// pub mod speakrs;

#[async_trait]
pub trait Diarizer: Send + Sync {
    /// Anota segments existentes com speaker labels baseado no áudio.
    async fn diarize(
        &self,
        wav: &Path,
        segments: Vec<TranscriptSegment>,
    ) -> Result<Vec<TranscriptSegment>>;
}

pub fn build(config: &DiarizerConfig) -> Result<Arc<dyn Diarizer>> {
    match config {
        DiarizerConfig::None => Ok(Arc::new(none::NoneDiarizer)),

        DiarizerConfig::Pyannote {
            segmentation_model,
            embedding_model,
        } => {
            #[cfg(feature = "diarize-pyannote")]
            {
                Ok(Arc::new(pyannote::PyannoteDiarizer::new(
                    segmentation_model.into(),
                    embedding_model.into(),
                )?))
            }
            #[cfg(not(feature = "diarize-pyannote"))]
            {
                let _ = (segmentation_model, embedding_model);
                tracing::warn!("diarize-pyannote not compiled; falling back to None");
                Ok(Arc::new(none::NoneDiarizer))
            }
        }

        DiarizerConfig::Speakrs {
            model_dir,
            accelerator,
        } => {
            let _ = (model_dir, accelerator);
            tracing::warn!("speakrs not yet implemented; falling back to None");
            Ok(Arc::new(none::NoneDiarizer))
        }
    }
}
