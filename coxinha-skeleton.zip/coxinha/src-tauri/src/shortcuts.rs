//! Global shortcuts. Registrados no startup, persistentes enquanto app rodando.
//!
//! Cada shortcut abre a janela e navega pra uma rota específica.

use std::sync::Arc;

use anyhow::Result;
use tauri::{AppHandle, Emitter, Manager};
use tauri_plugin_global_shortcut::{GlobalShortcutExt, Shortcut, ShortcutState};
use tokio::sync::Mutex;

use crate::config::AppState;

pub fn register_all(app: &AppHandle, state: &Arc<Mutex<AppState>>) -> Result<()> {
    let cfg = tauri::async_runtime::block_on(async {
        let s = state.lock().await;
        s.config.shortcuts.clone()
    });

    let gs = app.global_shortcut();
    for binding in [
        (&cfg.new_note, "new-note"),
        (&cfg.open_app, "open-app"),
        (&cfg.agenda, "agenda"),
        (&cfg.meetings, "meetings"),
        (&cfg.toggle_recording, "toggle-recording"),
    ] {
        match binding.0.parse::<Shortcut>() {
            Ok(shortcut) => {
                if let Err(e) = gs.register(shortcut) {
                    tracing::warn!("failed to register {}: {:?}", binding.0, e);
                }
            }
            Err(e) => tracing::warn!("invalid shortcut '{}': {:?}", binding.0, e),
        }
    }
    Ok(())
}

pub fn handle_shortcut(
    app: &AppHandle,
    shortcut: &Shortcut,
    event: tauri_plugin_global_shortcut::ShortcutEvent,
) {
    if event.state() != ShortcutState::Pressed {
        return;
    }

    let route = route_for(shortcut);
    tracing::info!("shortcut {} -> {}", shortcut, route);

    // Show + focus main window
    if let Some(window) = app.get_webview_window("main") {
        let _ = window.show();
        let _ = window.set_focus();
        let _ = window.unminimize();
    }

    // Emite evento pro frontend pra navegar + focar
    let _ = app.emit("navigate", route);
}

fn route_for(sc: &Shortcut) -> &'static str {
    // Rotas frontend (quem decide como renderiza é o React)
    let s = format!("{}", sc);
    if s.contains("KeyN") {
        "/notes/new"
    } else if s.contains("KeyA") {
        "/agenda"
    } else if s.contains("KeyM") {
        "/meetings"
    } else if s.contains("KeyR") {
        "/actions/toggle-recording"
    } else {
        "/"
    }
}
