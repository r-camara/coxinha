//! Gerador de resumos via `genai` (Ollama, Claude, OpenAI, Groq, OpenRouter).
//!
//! Prompt template em português por default (o usuário é brasileiro).
//! Customizável via `~/coxinha/.coxinha/prompts/summary.md` quando existir.

use std::sync::Arc;

use anyhow::{Context, Result};
use shared::*;
use uuid::Uuid;

use crate::storage::Storage;

const DEFAULT_PROMPT: &str = r#"Você é um assistente que resume reuniões em português do Brasil.

Abaixo está a transcrição de uma reunião. Produza um resumo estruturado em markdown contendo:

- **Resumo executivo** (2-3 frases)
- **Tópicos discutidos** (bullets, 1 linha cada)
- **Decisões tomadas** (se houver)
- **Ações/próximos passos** (se houver, com responsável se mencionado)
- **Pontos em aberto** (questões não resolvidas)

Seja objetivo, não invente informação que não está na transcrição.

---

Transcrição:
{transcript}
"#;

pub struct Summarizer {
    provider: LlmProvider,
    storage: Arc<Storage>,
}

impl Summarizer {
    pub fn new(provider: LlmProvider, storage: Arc<Storage>) -> Self {
        Self { provider, storage }
    }

    pub async fn summarize_meeting(&self, id: Uuid) -> Result<String> {
        let meeting_dir = self.storage.meeting_dir(id);
        let transcript_path = meeting_dir.join("transcript.json");
        let transcript_raw = tokio::fs::read_to_string(&transcript_path)
            .await
            .with_context(|| format!("reading {}", transcript_path.display()))?;
        let transcript: Transcript = serde_json::from_str(&transcript_raw)?;

        let text = format_transcript(&transcript);
        let prompt = DEFAULT_PROMPT.replace("{transcript}", &text);

        let summary = self.call_llm(&prompt).await?;

        // Persiste summary.md
        tokio::fs::write(meeting_dir.join("summary.md"), &summary).await?;
        Ok(summary)
    }

    async fn call_llm(&self, prompt: &str) -> Result<String> {
        use genai::chat::{ChatMessage, ChatRequest};
        use genai::Client;

        let (model, client) = match &self.provider {
            LlmProvider::Ollama { endpoint, model } => {
                // `genai` lê OLLAMA_HOST env var
                std::env::set_var("OLLAMA_HOST", endpoint);
                (model.clone(), Client::default())
            }
            LlmProvider::Claude { model } => (model.clone(), Client::default()),
            LlmProvider::OpenAI { model } => (model.clone(), Client::default()),
            LlmProvider::Groq { model } => (model.clone(), Client::default()),
            LlmProvider::OpenRouter { model } => (model.clone(), Client::default()),
        };

        let chat_req = ChatRequest::new(vec![ChatMessage::user(prompt)]);

        let res = client
            .exec_chat(&model, chat_req, None)
            .await
            .map_err(|e| anyhow::anyhow!("LLM error: {:?}", e))?;

        res.content_text_as_str()
            .map(|s| s.to_string())
            .ok_or_else(|| anyhow::anyhow!("empty LLM response"))
    }
}

fn format_transcript(t: &Transcript) -> String {
    let mut out = String::new();
    for seg in &t.segments {
        let speaker = seg.speaker.as_deref().unwrap_or("Speaker");
        out.push_str(&format!(
            "[{:.1}s] {}: {}\n",
            seg.start, speaker, seg.text
        ));
    }
    out
}
