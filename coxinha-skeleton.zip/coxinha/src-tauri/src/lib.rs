//! Entrada da biblioteca Coxinha.
//!
//! - Configura logging
//! - Registra plugins Tauri
//! - Cria tray icon
//! - Registra global shortcuts
//! - Expõe commands IPC tipados (specta)

mod call_detector;
mod config;
mod db;
mod diarizer;
mod recorder;
mod shortcuts;
mod storage;
mod summarizer;
mod transcriber;
mod tray;

use std::sync::Arc;
use tauri::Manager;
use tokio::sync::Mutex;
use tracing::info;

use crate::config::AppState;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    // Logging
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "coxinha=debug,info".into()),
        )
        .init();

    info!("Coxinha starting...");

    // Specta: gera bindings TypeScript dos commands
    let builder = tauri_specta::Builder::<tauri::Wry>::new()
        .commands(tauri_specta::collect_commands![
            // Notes
            commands::create_note,
            commands::update_note,
            commands::delete_note,
            commands::list_notes,
            commands::get_note,
            commands::search_notes,
            // Meetings
            commands::list_meetings,
            commands::get_meeting,
            commands::start_recording,
            commands::stop_recording,
            commands::transcribe_meeting,
            commands::summarize_meeting,
            // Call detection
            commands::get_active_calls,
            // Attachments
            commands::save_attachment,
            // Config
            commands::get_config,
            commands::update_config,
        ])
        .events(tauri_specta::collect_events![
            events::CallDetected,
            events::RecordingProgress,
            events::TranscriptionProgress,
        ]);

    // Gera bindings TS durante dev
    #[cfg(debug_assertions)]
    builder
        .export(
            specta_typescript::Typescript::default()
                .bigint(specta_typescript::BigIntExportBehavior::Number),
            "../src/lib/bindings.ts",
        )
        .expect("Failed to export TS bindings");

    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_notification::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(
            tauri_plugin_global_shortcut::Builder::new()
                .with_handler(shortcuts::handle_shortcut)
                .build(),
        )
        .plugin(tauri_plugin_autostart::init(
            tauri_plugin_autostart::MacosLauncher::LaunchAgent,
            Some(vec!["--hidden"]),
        ))
        .invoke_handler(builder.invoke_handler())
        .setup(move |app| {
            builder.mount_events(app);

            // Estado global compartilhado
            let state = Arc::new(Mutex::new(AppState::initialize(app.handle())?));
            app.manage(state.clone());

            // Configura tray
            tray::setup(app.handle())?;

            // Registra shortcuts globais
            shortcuts::register_all(app.handle(), &state)?;

            // Spawn call detector em background
            let handle = app.handle().clone();
            tauri::async_runtime::spawn(async move {
                if let Err(e) = call_detector::run_loop(handle).await {
                    tracing::error!("Call detector loop failed: {:?}", e);
                }
            });

            info!("Coxinha ready");
            Ok(())
        })
        .on_window_event(|window, event| {
            // Fechar janela = hide, não close (tray-resident)
            if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                let _ = window.hide();
                api.prevent_close();
            }
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}

// ---- Commands (IPC) ----

mod commands {
    use super::*;
    use shared::*;
    use uuid::Uuid;

    #[tauri::command]
    #[specta::specta]
    pub async fn create_note(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
        title: String,
        content: String,
    ) -> Result<Note, String> {
        let state = state.lock().await;
        state
            .storage
            .create_note(&title, &content)
            .await
            .map_err(|e| e.to_string())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn update_note(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
        id: Uuid,
        content: String,
    ) -> Result<(), String> {
        let state = state.lock().await;
        state
            .storage
            .update_note(id, &content)
            .await
            .map_err(|e| e.to_string())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn delete_note(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
        id: Uuid,
    ) -> Result<(), String> {
        let state = state.lock().await;
        state
            .storage
            .delete_note(id)
            .await
            .map_err(|e| e.to_string())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn list_notes(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
    ) -> Result<Vec<Note>, String> {
        let state = state.lock().await;
        state.storage.list_notes().await.map_err(|e| e.to_string())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn get_note(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
        id: Uuid,
    ) -> Result<NoteContent, String> {
        let state = state.lock().await;
        state.storage.get_note(id).await.map_err(|e| e.to_string())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn search_notes(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
        query: String,
    ) -> Result<Vec<Note>, String> {
        let state = state.lock().await;
        state
            .storage
            .search_notes(&query)
            .await
            .map_err(|e| e.to_string())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn list_meetings(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
    ) -> Result<Vec<Meeting>, String> {
        let state = state.lock().await;
        state
            .storage
            .list_meetings()
            .await
            .map_err(|e| e.to_string())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn get_meeting(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
        id: Uuid,
    ) -> Result<Meeting, String> {
        let state = state.lock().await;
        state
            .storage
            .get_meeting(id)
            .await
            .map_err(|e| e.to_string())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn start_recording(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
        title: String,
    ) -> Result<Uuid, String> {
        let mut state = state.lock().await;
        state
            .recorder
            .start(&title)
            .await
            .map_err(|e| e.to_string())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn stop_recording(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
    ) -> Result<Meeting, String> {
        let mut state = state.lock().await;
        state.recorder.stop().await.map_err(|e| e.to_string())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn transcribe_meeting(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
        id: Uuid,
    ) -> Result<Transcript, String> {
        let state = state.lock().await;
        state
            .transcriber
            .transcribe_meeting(id)
            .await
            .map_err(|e| e.to_string())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn summarize_meeting(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
        id: Uuid,
    ) -> Result<String, String> {
        let state = state.lock().await;
        state
            .summarizer
            .summarize_meeting(id)
            .await
            .map_err(|e| e.to_string())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn get_active_calls(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
    ) -> Result<Vec<ActiveCall>, String> {
        let state = state.lock().await;
        Ok(state.active_calls.clone())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn save_attachment(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
        filename: String,
        bytes: Vec<u8>,
    ) -> Result<String, String> {
        let state = state.lock().await;
        state
            .storage
            .save_attachment(&filename, &bytes)
            .await
            .map_err(|e| e.to_string())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn get_config(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
    ) -> Result<AppConfig, String> {
        let state = state.lock().await;
        Ok(state.config.clone())
    }

    #[tauri::command]
    #[specta::specta]
    pub async fn update_config(
        state: tauri::State<'_, Arc<Mutex<AppState>>>,
        config: AppConfig,
    ) -> Result<(), String> {
        let mut state = state.lock().await;
        state.update_config(config).await.map_err(|e| e.to_string())
    }
}

// ---- Eventos (emitidos pro frontend) ----

mod events {
    use serde::{Deserialize, Serialize};
    use specta::Type;
    use tauri_specta::Event;

    #[derive(Debug, Clone, Serialize, Deserialize, Type, Event)]
    pub struct CallDetected {
        pub app_name: String,
        pub process_name: String,
    }

    #[derive(Debug, Clone, Serialize, Deserialize, Type, Event)]
    pub struct RecordingProgress {
        pub meeting_id: uuid::Uuid,
        pub duration_seconds: u32,
        pub level_db: f32,
    }

    #[derive(Debug, Clone, Serialize, Deserialize, Type, Event)]
    pub struct TranscriptionProgress {
        pub meeting_id: uuid::Uuid,
        pub percent: f32,
        pub message: String,
    }
}
