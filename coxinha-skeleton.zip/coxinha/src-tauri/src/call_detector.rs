//! Detector de chamadas em andamento.
//!
//! Loop assíncrono consulta audio sessions do Windows via COM
//! (`IAudioSessionManager2` + `IAudioSessionControl2`). Para cada
//! sessão em estado `AudioSessionStateActive`, resolve o processo
//! dono e marca como "call detected" se combinar com uma lista conhecida.
//!
//! TODO F1:
//! - [ ] Implementar enumeração COM via `windows` crate
//! - [ ] Cache de PIDs já vistos pra evitar spam
//! - [ ] Mapa de process name → app label (e.g. `ms-teams.exe` → Teams)
//! - [ ] Lidar com browsers (Chrome/Edge → Meet, Webex, Slack call)

use anyhow::Result;
use shared::*;
use std::collections::HashSet;
use std::time::Duration;
use tauri::{AppHandle, Emitter, Manager};

/// Apps conhecidos que fazem chamadas. Match case-insensitive do nome do executável.
const KNOWN_CALL_APPS: &[(&str, &str)] = &[
    ("ms-teams.exe", "Microsoft Teams"),
    ("teams.exe", "Microsoft Teams"),
    ("zoom.exe", "Zoom"),
    ("webex.exe", "Webex"),
    ("discord.exe", "Discord"),
    ("slack.exe", "Slack"),
    // Browsers: difícil saber se é call, mas podemos oferecer gravação mesmo assim
    // ("chrome.exe", "Browser (Google Meet?)"),
    // ("msedge.exe", "Browser (Teams Web?)"),
];

pub async fn run_loop(app: AppHandle) -> Result<()> {
    let mut seen: HashSet<u32> = HashSet::new();
    let mut tick = tokio::time::interval(Duration::from_secs(3));

    loop {
        tick.tick().await;

        let active = poll_active_calls().await.unwrap_or_default();

        for call in &active {
            if !seen.contains(&call.pid) {
                seen.insert(call.pid);
                tracing::info!("Call detected: {} ({})", call.app_name, call.process_name);

                // Emite evento pro frontend
                let _ = app.emit(
                    "call-detected",
                    serde_json::json!({
                        "app_name": call.app_name,
                        "process_name": call.process_name,
                    }),
                );
            }
        }

        // Atualiza state global
        if let Some(state) = app.try_state::<std::sync::Arc<tokio::sync::Mutex<crate::config::AppState>>>() {
            let mut st = state.lock().await;
            st.active_calls = active;
            // Esquece PIDs que sumiram
            seen.retain(|pid| st.active_calls.iter().any(|c| c.pid == *pid));
        }
    }
}

#[cfg(target_os = "windows")]
async fn poll_active_calls() -> Result<Vec<ActiveCall>> {
    // TODO: implementar via windows crate
    // Esboço do que precisa:
    //
    // use windows::Win32::Media::Audio::*;
    // use windows::Win32::System::Com::*;
    //
    // CoInitializeEx(...)?;
    // let enumerator: IMMDeviceEnumerator = CoCreateInstance(...)?;
    // let device = enumerator.GetDefaultAudioEndpoint(eRender, eConsole)?;
    // let sessions: IAudioSessionManager2 = device.Activate(...)?;
    // let session_enum = sessions.GetSessionEnumerator()?;
    // for i in 0..session_enum.GetCount()? {
    //     let session: IAudioSessionControl2 = ...;
    //     let state = session.GetState()?;
    //     if state != AudioSessionStateActive { continue; }
    //     let pid = session.GetProcessId()?;
    //     let process_name = resolve_process_name(pid)?;
    //     if matches_known_app(&process_name) { ... }
    // }
    Ok(Vec::new())
}

#[cfg(not(target_os = "windows"))]
async fn poll_active_calls() -> Result<Vec<ActiveCall>> {
    // Stub pra dev fora de Windows
    Ok(Vec::new())
}

#[allow(dead_code)]
fn match_known_app(process_name: &str) -> Option<&'static str> {
    let lowered = process_name.to_lowercase();
    KNOWN_CALL_APPS
        .iter()
        .find(|(exe, _)| lowered == *exe)
        .map(|(_, name)| *name)
}
