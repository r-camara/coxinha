//! Abstração do vault. Filesystem é canonical, DB é índice.
//!
//! Regras:
//! - Notas viram arquivos `.md` em `notes/`
//! - Nome do arquivo é slug do título + `-{curta id}`
//! - Attachments em `attachments/` (WebP auto-comprimido ao paste)
//! - Meetings em `meetings/{slug}/` com metadata.json, recording.wav etc

use std::path::{Path, PathBuf};
use std::sync::Arc;

use anyhow::{Context, Result};
use chrono::Utc;
use shared::*;
use tokio::fs;
use uuid::Uuid;

use crate::db::Db;

pub struct Storage {
    vault: PathBuf,
    db: Arc<Db>,
}

impl Storage {
    pub fn new(vault: PathBuf, db: Arc<Db>) -> Self {
        Self { vault, db }
    }

    pub fn vault(&self) -> &Path {
        &self.vault
    }

    // ---- Notes ----

    pub async fn create_note(&self, title: &str, content: &str) -> Result<Note> {
        let id = Uuid::new_v4();
        let now = Utc::now();
        let filename = format!(
            "{}-{}.md",
            slug(title),
            id.simple().to_string().chars().take(6).collect::<String>()
        );
        let rel_path = format!("notes/{}", filename);
        let abs_path = self.vault.join(&rel_path);

        fs::write(&abs_path, content).await?;

        let note = Note {
            id,
            title: title.to_string(),
            path: rel_path,
            tags: extract_tags(content),
            created_at: now,
            updated_at: now,
        };
        self.db.upsert_note(&note, content)?;
        Ok(note)
    }

    pub async fn update_note(&self, id: Uuid, content: &str) -> Result<()> {
        let note = self
            .db
            .get_note(id)?
            .with_context(|| format!("note {} not found", id))?;
        let abs = self.vault.join(&note.path);
        fs::write(&abs, content).await?;

        let mut updated = note;
        updated.updated_at = Utc::now();
        updated.tags = extract_tags(content);
        updated.title = first_heading(content).unwrap_or(updated.title);
        self.db.upsert_note(&updated, content)?;
        Ok(())
    }

    pub async fn delete_note(&self, id: Uuid) -> Result<()> {
        if let Some(note) = self.db.get_note(id)? {
            let abs = self.vault.join(&note.path);
            if abs.exists() {
                fs::remove_file(&abs).await?;
            }
        }
        self.db.delete_note(id)?;
        Ok(())
    }

    pub async fn list_notes(&self) -> Result<Vec<Note>> {
        self.db.list_notes()
    }

    pub async fn get_note(&self, id: Uuid) -> Result<NoteContent> {
        let note = self
            .db
            .get_note(id)?
            .with_context(|| format!("note {} not found", id))?;
        let markdown = fs::read_to_string(self.vault.join(&note.path)).await?;
        Ok(NoteContent { note, markdown })
    }

    pub async fn search_notes(&self, query: &str) -> Result<Vec<Note>> {
        self.db.search_notes(query)
    }

    // ---- Meetings ----

    pub async fn list_meetings(&self) -> Result<Vec<Meeting>> {
        self.db.list_meetings()
    }

    pub async fn get_meeting(&self, id: Uuid) -> Result<Meeting> {
        self.db
            .get_meeting(id)?
            .with_context(|| format!("meeting {} not found", id))
    }

    pub fn meeting_dir(&self, id: Uuid) -> PathBuf {
        self.vault.join("meetings").join(id.to_string())
    }

    // ---- Attachments ----

    pub async fn save_attachment(&self, filename: &str, bytes: &[u8]) -> Result<String> {
        // Tenta comprimir pra WebP se for imagem
        let (final_bytes, final_name) = compress_if_image(filename, bytes);

        let stamp = Utc::now().format("%Y-%m-%d-%H%M%S");
        let safe_name = format!("{}-{}", stamp, sanitize(&final_name));
        let rel = format!("attachments/{}", safe_name);
        let abs = self.vault.join(&rel);
        fs::write(&abs, &final_bytes).await?;
        Ok(rel)
    }
}

/// Tenta reduzir/converter imagem pra WebP. Fallback = bytes originais.
fn compress_if_image(filename: &str, bytes: &[u8]) -> (Vec<u8>, String) {
    if !is_image_ext(filename) {
        return (bytes.to_vec(), filename.to_string());
    }

    let Ok(img) = image::load_from_memory(bytes) else {
        return (bytes.to_vec(), filename.to_string());
    };

    // Redimensiona se muito grande
    const MAX_WIDTH: u32 = 1600;
    let resized = if img.width() > MAX_WIDTH {
        let ratio = MAX_WIDTH as f32 / img.width() as f32;
        let new_height = (img.height() as f32 * ratio) as u32;
        img.resize(MAX_WIDTH, new_height, image::imageops::FilterType::Lanczos3)
    } else {
        img
    };

    // Encode como WebP
    let mut out: Vec<u8> = Vec::new();
    let encoder = image::codecs::webp::WebPEncoder::new_lossless(&mut out);
    if resized.write_with_encoder(encoder).is_ok() {
        let new_name = change_ext(filename, "webp");
        return (out, new_name);
    }

    (bytes.to_vec(), filename.to_string())
}

fn is_image_ext(filename: &str) -> bool {
    matches!(
        Path::new(filename)
            .extension()
            .and_then(|e| e.to_str())
            .map(|s| s.to_lowercase())
            .as_deref(),
        Some("png" | "jpg" | "jpeg" | "gif" | "bmp")
    )
}

fn change_ext(filename: &str, ext: &str) -> String {
    let p = Path::new(filename);
    let stem = p.file_stem().and_then(|s| s.to_str()).unwrap_or("image");
    format!("{}.{}", stem, ext)
}

fn slug(s: &str) -> String {
    let lower = s.to_lowercase();
    let replaced: String = lower
        .chars()
        .map(|c| {
            if c.is_alphanumeric() {
                c
            } else if c.is_whitespace() || c == '-' || c == '_' {
                '-'
            } else {
                '-'
            }
        })
        .collect();
    // Colapsa múltiplos '-'
    let mut out = String::new();
    let mut prev = '_';
    for c in replaced.chars() {
        if c == '-' && prev == '-' {
            continue;
        }
        out.push(c);
        prev = c;
    }
    let trimmed = out.trim_matches('-').to_string();
    if trimmed.is_empty() {
        "nota".into()
    } else {
        trimmed.chars().take(60).collect()
    }
}

fn sanitize(s: &str) -> String {
    s.chars()
        .map(|c| {
            if c.is_alphanumeric() || c == '.' || c == '-' || c == '_' {
                c
            } else {
                '_'
            }
        })
        .collect()
}

fn extract_tags(markdown: &str) -> Vec<String> {
    // Pega #tags do texto (exclui # de headings)
    let mut tags = Vec::new();
    for word in markdown.split_whitespace() {
        if let Some(rest) = word.strip_prefix('#') {
            if !rest.is_empty() && rest.chars().next().map_or(false, |c| c.is_alphabetic()) {
                let clean: String = rest
                    .chars()
                    .take_while(|c| c.is_alphanumeric() || *c == '-' || *c == '_')
                    .collect();
                if !clean.is_empty() && !tags.contains(&clean) {
                    tags.push(clean);
                }
            }
        }
    }
    tags
}

fn first_heading(markdown: &str) -> Option<String> {
    for line in markdown.lines() {
        let trimmed = line.trim_start();
        if let Some(rest) = trimmed.strip_prefix('#') {
            let title = rest.trim_start_matches('#').trim();
            if !title.is_empty() {
                return Some(title.to_string());
            }
        }
    }
    None
}
