# Status do Skeleton

Este skeleton foi gerado como ponto de partida. Nem tudo compila ainda
out-of-the-box — há stubs que precisam implementação real e features
opcionais que dependem de crates externas.

## ✅ O que está implementado de verdade

- **Documentação completa** — README, ARCHITECTURE, DECISIONS (11 ADRs), ROADMAP, CLAUDE.md
- **Cargo workspace** configurado (`src-tauri` + `shared`)
- **Tipos compartilhados** (`shared/src/lib.rs`) com `specta::Type` pro IPC
- **Commands Tauri** (`lib.rs`) definindo API completa do F1
- **DB SQLite + FTS5** (`db.rs`) funcional
- **Storage filesystem** (`storage.rs`) com compressão WebP backend
- **Tray + shortcuts + config** básicos prontos
- **Frontend React** com BlockNote, compressão WebP client-side, Zustand store
- **GitHub Actions** CI + release
- **Scripts** download de modelos + setup WSL

## ⚠️ Stubs que precisam código real

Estes arquivos têm `TODO` explícito — a estrutura está pronta, falta
implementar:

- **`recorder.rs`** — captura cpal + wasapi real (só o scaffold de
  start/stop está lá, sem áudio sendo gravado ainda)
- **`call_detector.rs`** — enumeração COM via `windows` crate
  (função `poll_active_calls` retorna vec vazio)
- **`diarizer/pyannote.rs`** — chamada real ao `pyannote-rs`
  (hoje devolve segments sem speaker labels)
- **`transcribe_meeting` command** — precisa conectar
  recorder → transcriber → diarizer → salvar `transcript.json`

## ❓ Pode precisar ajuste

- **`transcriber/parakeet.rs`** — a API `transcribe-rs 0.3` foi usada
  conforme docs públicas, mas o campo `result.segments` e
  `result.language` pode diferir. Valide com `cargo check --features stt-parakeet`.
- **`tauri-specta 2.0.0-rc`** — versão RC, pode ter mudado desde a
  geração. Se `cargo build` reclamar, pin exata `=2.0.0-rc.X`.
- **`capabilities/default.json`** — permissões mínimas. Adicione
  conforme for usando mais APIs Tauri.
- **`icons/`** — só tem README. Gere os ícones reais:
  ```bash
  pnpm tauri icon assets/coxinha.png
  ```

## 🚧 Não existe ainda

- Arquivo `eslint.config.js` (mas `pnpm lint` é referenciado no
  package.json). Criar ou remover do script.
- Testes. Nenhum ainda. F1 deveria incluir pelo menos smoke tests
  em `db.rs` e `storage.rs`.
- `src/components/MeetingsList.tsx`, `Agenda.tsx`,
  `CallDetectedToast.tsx` — App.tsx só tem placeholders inline.
- Migrations formais de DB (hoje é SQL inline em `Db::migrate`).

## Primeira rodada recomendada

1. Coloque ícones em `src-tauri/icons/` (ou comente `bundle.icon`
   em `tauri.conf.json` temporariamente)
2. `pnpm install`
3. `./scripts/download-models.sh` (baixa Whisper base + pyannote, ~300MB)
4. `pnpm tauri dev`

Se der erro, 90% vai ser em uma das crates opcionais (parakeet,
pyannote). Comente a feature correspondente em `src-tauri/Cargo.toml`
pra isolar.

## Vibe coding com Claude Code

O projeto já tem `CLAUDE.md` curto apontando pros outros docs.
Começa de dentro da raiz:

```bash
cd coxinha
claude
```

Claude vai ler `CLAUDE.md` → ARCHITECTURE → DECISIONS automaticamente.
Sugestão de primeiro prompt:

> "Leia os docs do projeto e me diga qual é o primeiro TODO mais
> impactante pra eu atacar. Sugira a sequência das próximas 3-5 PRs."
