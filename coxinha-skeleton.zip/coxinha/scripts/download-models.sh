#!/usr/bin/env bash
# Baixa modelos pro Coxinha.
#
# Default: Whisper base (mais leve, ~150MB) + pyannote segmentation + wespeaker.
# Use --parakeet pra baixar Parakeet TDT v3 INT8 (~550MB).
# Use --whisper-large pra Whisper large-v3 (~3GB, melhor qualidade).

set -euo pipefail

VAULT_DIR="${VAULT_DIR:-$HOME/coxinha}"
MODELS_DIR="$VAULT_DIR/.coxinha/models"
mkdir -p "$MODELS_DIR"

WANT_WHISPER_BASE=1
WANT_WHISPER_LARGE=0
WANT_PARAKEET=0
WANT_PYANNOTE=1

for arg in "$@"; do
  case "$arg" in
    --parakeet) WANT_PARAKEET=1 ;;
    --whisper-large) WANT_WHISPER_LARGE=1 ;;
    --no-whisper) WANT_WHISPER_BASE=0 ;;
    --no-pyannote) WANT_PYANNOTE=0 ;;
    --all) WANT_WHISPER_LARGE=1; WANT_PARAKEET=1 ;;
    *) echo "unknown arg: $arg"; exit 1 ;;
  esac
done

download() {
  local url="$1"
  local dest="$2"
  if [[ -f "$dest" ]]; then
    echo "✔ $dest já existe"
    return
  fi
  echo "↓ baixando $(basename "$dest")..."
  curl -L --fail --progress-bar -o "$dest" "$url"
}

if [[ "$WANT_WHISPER_BASE" == 1 ]]; then
  echo "== Whisper base =="
  download \
    "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin" \
    "$MODELS_DIR/ggml-base.bin"
fi

if [[ "$WANT_WHISPER_LARGE" == 1 ]]; then
  echo "== Whisper large-v3 =="
  download \
    "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3.bin" \
    "$MODELS_DIR/ggml-large-v3.bin"
fi

if [[ "$WANT_PARAKEET" == 1 ]]; then
  echo "== Parakeet TDT 0.6B v3 INT8 =="
  PARAKEET_DIR="$MODELS_DIR/parakeet-tdt-0.6b-v3-int8"
  mkdir -p "$PARAKEET_DIR"
  # URLs exatos conforme o release do modelo ONNX INT8 no HuggingFace
  # TODO: confirmar paths finais quando estabilizarem
  download \
    "https://huggingface.co/istupakov/parakeet-tdt-0.6b-v3-onnx/resolve/main/encoder-model.int8.onnx" \
    "$PARAKEET_DIR/encoder-model.int8.onnx"
  download \
    "https://huggingface.co/istupakov/parakeet-tdt-0.6b-v3-onnx/resolve/main/decoder_joint-model.int8.onnx" \
    "$PARAKEET_DIR/decoder_joint-model.int8.onnx"
  download \
    "https://huggingface.co/istupakov/parakeet-tdt-0.6b-v3-onnx/resolve/main/vocab.txt" \
    "$PARAKEET_DIR/vocab.txt"
fi

if [[ "$WANT_PYANNOTE" == 1 ]]; then
  echo "== pyannote segmentation + wespeaker =="
  download \
    "https://github.com/thewh1teagle/pyannote-rs/releases/download/v0.1.0/segmentation-3.0.onnx" \
    "$MODELS_DIR/segmentation-3.0.onnx"
  download \
    "https://github.com/thewh1teagle/pyannote-rs/releases/download/v0.1.0/wespeaker_en_voxceleb_CAM++.onnx" \
    "$MODELS_DIR/wespeaker_en_voxceleb_CAM++.onnx"
fi

echo ""
echo "✔ Modelos em $MODELS_DIR"
echo ""
echo "Atualize $VAULT_DIR/.coxinha/config.toml conforme os paths baixados."
