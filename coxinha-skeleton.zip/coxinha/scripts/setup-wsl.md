# Setup Dev Windows 11 + WSL2

## Windows side

1. **WSL2 Ubuntu** (se ainda não tem):
   ```powershell
   wsl --install -d Ubuntu
   ```

2. **`.wslconfig` em `C:\Users\<você>\.wslconfig`**:
   ```ini
   [wsl2]
   networkingMode=mirrored
   dnsTunneling=true
   firewall=false
   autoProxy=true
   memory=12GB
   ```

   Reinicie WSL: `wsl --shutdown` no PowerShell.

3. **Docker Desktop** com "Use the WSL2 based engine" e integração com Ubuntu
   habilitadas (Settings → Resources → WSL Integration).

4. **WebView2 runtime** já vem no Windows 11 por padrão. Se faltar:
   https://developer.microsoft.com/microsoft-edge/webview2/

5. (Opcional) **CUDA Toolkit 12.6** pra build com GPU no Windows:
   https://developer.nvidia.com/cuda-toolkit

## WSL side

```bash
# Sistema
sudo apt update && sudo apt install -y \
  build-essential curl file pkg-config libssl-dev \
  libgtk-3-dev libwebkit2gtk-4.1-dev \
  libappindicator3-dev librsvg2-dev patchelf

# Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
source "$HOME/.cargo/env"

# Node + pnpm
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
npm install -g pnpm

# Clone do projeto
mkdir -p ~/projects
cd ~/projects
git clone <seu-repo> coxinha
cd coxinha

# Deps
pnpm install

# Modelos
./scripts/download-models.sh
```

## Rodando

**Dev via WSL (GUI Linux com WSLg):**
```bash
cd ~/projects/coxinha
pnpm tauri dev
```

**Build Windows nativo** (precisa rodar no próprio Windows, não no WSL):
```powershell
cd C:\Users\<você>\projects\coxinha
pnpm install
pnpm tauri build
```

Ou deixa o GitHub Actions buildar no `release.yml` quando tu criar uma tag.

## Dicas

- Projeto **deve** ficar em `/home/<você>/` no WSL, NUNCA em `/mnt/c/`.
  Performance de I/O cai 10x em `/mnt/c/`.
- VS Code com extensão "Remote - WSL" abre o projeto nativo no WSL:
  `code ~/projects/coxinha`
- `cargo-watch` pra hot-reload backend durante dev:
  ```bash
  cargo install cargo-watch
  ```
